package assignmentvi;


import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AssignmentVI {

    static List<DNode> readUTF8(String path){

        List<DNode> data = new ArrayList<>();
        BufferedReader br = null;
        String line;
        String splitBy = ",";

        try{

            br = new BufferedReader(new InputStreamReader(new FileInputStream(path), "UTF-8"));

            br.read();      //Clear BOM

            while((line = br.readLine()) != null){

                data.add(new DNode(line));
            }

        } catch(FileNotFoundException e){

            System.out.println("Error! File not found");

        } catch(IOException e){

            System.out.println("Error! Unable to read the content");

        } finally{

            if(br != null){

                try {
                    br.close();
                } catch (IOException ex) {
                    Logger.getLogger(AssignmentVI.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

        return data;
    }

    static int removeDuplicates(List<DNode> sortedList){

        List<DNode> dup = new ArrayList<>();

        for(int i = 0; i < sortedList.size() - 1; i++){

            if(sortedList.get(i).compareAll(sortedList.get(i + 1))){

//                if(!dup.contains(sortedList.get(i + 1)))
                dup.add(sortedList.get(i + 1));
                sortedList.remove(i + 1);
//                i--;
            }
        }
        
        return dup.size();
    }

    public static void printMostRepeating(List<DNode> dict){

        int max = 0;
        int pos = 0;
        int count = 1;
        String curr = dict.get(0).getWord();

        for(int i = 0; i < dict.size(); i++){

            if(curr.equalsIgnoreCase(dict.get(i).getWord()))
                count++;
            else{
                count = 1;
                curr = dict.get(i).getWord();
            }
            if(max < count){
                max = count;
                pos = i;
            }
        }
        int first_repeated = pos - max + 1;

        System.out.println(dict.get(pos).getWord() + " has " + max + " meanings");
        printData(dict, first_repeated, pos);
    }

    static void printData(List<DNode> list, int startPos, int endPos){

        if(startPos == endPos)
            System.out.println(" [" + startPos + "] " + list.get(startPos).getWord() + " " + list.get(startPos).getMeaning() + " " + list.get(startPos).getType());

        else
            for (int i = startPos; i <= endPos; i++){

                System.out.println(" [" + (i + 1) + "] " + list.get(i).getWord() + " " + list.get(i).getMeaning() + " " + list.get(i).getType());
            }
    }

    static void findWords(List<DNode> list, String key){

        int count = 0;
        int endPos = 0;
        boolean found = false;

        //Trim all the white space
        key = key.replaceAll("\\s+", " ");
        key = key.trim();

        for(int i = 0; i < list.size(); i++){

            if(list.get(i).getWord().equalsIgnoreCase(key)){

                endPos = i;
                count++;
                found = true;
            }
        }

        if(found){

            int startPos = endPos - count + 1;

            System.out.println(count + " word(s) found at index [" + startPos + "] [" + endPos + "]");
            printData(list, startPos, endPos);
        }
        else
            System.out.println("Element not found");
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        boolean running = true;
        
        String filePath = "C:\\Users\\lenovo\\Desktop\\utf8lexitron.csv";

//        String filePath = "C:\\Users\\lenovo\\Desktop\\unicodelexitron.csv";

        List<DNode> list = readUTF8(filePath);

        System.out.println("Total records:" + list.size());

        Collections.sort(list);

        System.out.println("Duplicate:" + removeDuplicates(list));

        System.out.println("Remaining records:" + list.size());

        System.out.println("Finding the most repetitive word...");

        printMostRepeating(list);

//        list.forEach((t) -> {
//
//            System.out.println(t.getWord() + " " + t.getMeaning() + " " + t.getType());
//        });

        while(running){
            
            System.out.print("Enter a word:");
            String input = sc.nextLine();

            findWords(list, input);
            
            if(input.equalsIgnoreCase("end")){
                
                running = false;
            }
        }

        sc.close();
        System.out.println("Have a nice day!");
    }
}
