
package assignmentvi;


public class DNode implements Comparable<DNode>{
    
    private final String word;
    private final String meaning;
    private final String type;
    
    public DNode(String buff){
        
        buff = buff.trim().replaceAll("\\s+", " ");
        String str[] = buff.split(",");
        
        word = str[0];
        meaning = str[1];
        type = str[2];
    }
    
    @Override
    public int compareTo(DNode x){
        
        return this.word.compareToIgnoreCase(x.word);
    }
    
    public boolean compareAll(DNode x){
        
        if(this.word.compareToIgnoreCase(x.getWord()) != 0)
            return false;
        
        if(this.meaning.compareToIgnoreCase(x.getMeaning()) != 0)
            return false;
        
        return (this.type.compareToIgnoreCase(x.getType()) == 0);
    }
    
    public String getWord(){
        
        return this.word;
    }
    
    public String getMeaning(){
        
        return this.meaning;
    }
    
    public String getType(){
        
        return this.type;
    }
}
