package assignmentv;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Stack;


public class AssignmentV {
    
    static boolean running = true;
    static double previousAns;

    static boolean isConstant(String s){
        
        String[] constants = {"pi", "e", "ans"};
        
        boolean ans = false;
        
        for (String constant : constants) {
            
            if (constant.equalsIgnoreCase(s)) {
                
                ans = true;
            }
        }
        
        return ans;
    }
    
    static int isFunction(String s){
        
        //Index of each function    1     2     3      4      5     6       7     8     9     10
        String[] functions = {"", "sin","cos","tan","asin","acos","atan","sqrt","log","exp","abs"};
        
        int index = 0;
        
        for(int i = 1; i < functions.length; i++){
            
            if(functions[i].equalsIgnoreCase(s)){
                
                index = i;
                break;
            }
        }
        
        return index;
    }
    
    static boolean isNumber(String s){
        
        boolean check = true;
        
        try{
            
            Double.parseDouble(s);
        }catch(NumberFormatException e){
            
            check = false;
        }
        
        return check;
    }
    
    static String addSpace(String s){
        
        s = s.replace("+", " + ");
        s = s.replace("-", " - ");
        s = s.replace("*", " * ");
        s = s.replace("/", " / ");
        s = s.replace("^", " ^ ");
        s = s.replace("(", " ( ");
        s = s.replace(")", " ) ");
        s = s.replaceAll("\\s+", " ");
        s = s.trim();
        
        return s;
    }
    
    static void change_negative_sign(String[] token){
        
        if(token[0].equals("-")){
            
            token[0] = "!";
        }
        
        for(int i = 0; i < token.length - 1; i++){
            
            if((token[i + 1].equals("-")) && (token[i].matches("[+-/(*\\^]"))){
            
                token[i + 1] = "!";
            }
        }
    }
    
    static int checkGroup(String s){
        
        if(isNumber(s))
            return 1;
        else if(isConstant(s))
            return 1;
        else if(s.matches("[-+]"))
            return 2;
        else if(s.matches("[/*]"))
            return 3;
        else if(s.equals("^"))
            return 4;
        else if(s.equals("!"))
            return 5;
        else if(s.equals("("))
            return 7;
        else if(s.equals(")"))
            return 8;
        else if(isFunction(s) > 0)
            return 6;
        else
            return 0;
    }
    
    static int checkState(String[] token){
        
        int state = 0, next = 0, b = 0;
        
        for(int i = 0; i < token.length && state >= 0; i++){
            
            state = next;
            next = checkGroup(token[i]);
            
            if(2 <= next && next <= 4)
                next = 2;                   //+ - * / ^ are 2nd state
            if(next == 0)
                state = -1;            
            if(next == 7)
                b++;                        // b identifies brackets
            else if(next == 8)              // b++ when (
                b--;                        // b-- when )
            
            if(b < 0)
                state = -1;
            else if(state == 0 && (next == 8 || next == 2))
                state = -1;
            else if(state == 1 && (next == 1 || next == 6 || next ==7))
                state = -1;
            else if(state == 2 && (next == 2 || next == 8))
                state = -1;
            else if(state == 5 && (next == 2 || next == 8))
                state = -1;
            else if(state == 6 && (next != 7))
                state = -1;
            else if(state == 7 && (next == 2 || next == 8))
                state = -1;
        }
        
        if(b != 0 || state == -1)
            return -1;
        
        else
            return next;
    }
    
    static String[] addBracket(String[] token){
        
        String[] added = new String[token.length + 2];
        
        added[0] = "(";
        System.arraycopy(token, 0, added, 1, token.length);
        added[added.length - 1] = ")";
        
        return added;
    }
    
    //Using Arraylist but I implemented it as if it's a Stack class haha
    static String[] infixToPostfix(String[] infix_token){
        
        List<String> operatorStack = new ArrayList<>();
        List<String> postfix = new ArrayList<>();
        
        for(String s : infix_token){
            
            if(isNumber(s) || isConstant(s)){
                
                postfix.add(s);
            }
            else if(s.equals("(")){
                
                operatorStack.add(0, s);
            }
            else if(s.equals(")")){
                
                while(!operatorStack.isEmpty()){
                    
                    if(!operatorStack.get(0).equals("(")){
                        
                        postfix.add(operatorStack.get(0));
                        operatorStack.remove(0);
                    }
                    else{
                        
                        operatorStack.remove(0);        //Remove "("
                        break;
                    }
                }
            }
            else{
                
                if(operatorStack.size() == 1){
                    
                    operatorStack.add(0, s);
                }
                else{
                    
                    while(operatorStack.size() > 1 && checkGroup(operatorStack.get(0)) >= checkGroup(s) && checkGroup(operatorStack.get(0)) != 7){
                    
/*                      if(checkGroup(operatorStack.get(0)) >= checkGroup(s)){
                            
                            postfix.add(operatorStack.get(0));
                            operatorStack.remove(0);
                        }
                        else
                            break;                   
*/
                        postfix.add(operatorStack.get(0));      //More efficient
                        operatorStack.remove(0);
                    }

                    operatorStack.add(0, s);
                }
            }     
        }
        
        
        return postfix.toArray(new String[0]);
    }
    
    static boolean isUnaryOperator(String operator){
        
        return checkGroup(operator) == 5 || checkGroup(operator) == 6;
    }
    
    static boolean isBinaryOperator(String operator){
        
        return checkGroup(operator) == 2 || checkGroup(operator) == 3 || checkGroup(operator) == 4;
    }
    
    static double calcPostfix(String[] postfix){
        
        Stack<String> stack = new Stack<>();
        
        for(String s : postfix){
       
            if(isNumber(s) || isConstant(s)){
                
                stack.push(s);
            }
            else if(isUnaryOperator(s)){
                
                String a = stack.pop();
                double holder = 0;
                
                if(isNumber(a))
                    holder = Double.parseDouble(a);
                else if(a.equals("pi"))
                    holder = Math.PI;
                else if(a.equals("e"))
                    holder = Math.E;
                else if(a.equals("ans"))
                    holder = previousAns;
                
                if(checkGroup(s) ==  5)             //Negative
                    holder = -holder;
                else if(1 <= isFunction(s) && isFunction(s) <= 3){
                    
                    holder = holder * Math.PI / 180;
                    
                    switch (isFunction(s)) {
                    //Sine
                        case 1:
                            holder = Math.sin(holder);
                            break;
                    //Cosine
                        case 2:
                            holder = Math.cos(holder);
                            break;
                    //Tangent
                        case 3:
                            holder = Math.tan(holder);
                            break;
                        default:
                            break;
                    }
                }
                else if(4 <= isFunction(s) && isFunction(s) <= 6){
                    
                    switch (isFunction(s)){
                    //Arc sine
                        case 4:
                            holder = Math.asin(holder);
                            break;
                    //Arc cosine
                        case 5:
                            holder = Math.acos(holder);
                            break;
                    //Arc tangent
                        case 6:
                            holder = Math.atan(holder);
                            break;
                        default:
                            break;
                    }
                    
                    holder = holder / Math.PI * 180;
                }
                else if(isFunction(s) == 7)         //Square root
                    holder = Math.sqrt(holder);
                else if(isFunction(s) == 8)         //Natural log
                    holder = Math.log(holder);
                else if(isFunction(s) == 9)         //e raised to the power
                    holder = Math.exp(holder);
                else if(isFunction(s) == 10)        //Absolute value
                    holder = Math.abs(holder);
                
                stack.push(String.valueOf(holder));
            }
            else if(isBinaryOperator(s)){
                
                double a = 0;
                double b = 0;
                String cpy = stack.pop();
                
                if(isNumber(cpy))
                    a = Double.parseDouble(cpy);
                else if(cpy.equals("pi"))
                    a = Math.PI;
                else if(cpy.equals("e"))
                    a = Math.E;
                else if(cpy.equals("ans"))
                    a = previousAns;
                
                cpy = stack.pop();
                
                if(isNumber(cpy))
                    b = Double.parseDouble(cpy);
                else if(cpy.equals("pi"))
                    b = Math.PI;
                else if(cpy.equals("e"))
                    b = Math.E;
                else if(cpy.equals("ans"))
                    b = previousAns;
                
                switch (s) {
                    case "+":
                        a += b;
                        break;
                    case "-":
                        a = b - a;
                        break;
                    case "*":
                        a *= b;
                        break;
                    case "/":
                        a = b / a;
                        break;
                    case "^":
                        a = Math.pow(b, a);
                    default:
                        break;
                }
                
                stack.push(String.valueOf(a));
            }
        }
        
        return Double.parseDouble(stack.pop());
    }
   
    public static void main(String[] args) {
      
        //Try with resource block : try(...){}
        //will automatically closes any resources that are created
        //inside the block once it has been executed.
        //equivalent to     try{...}
        //                  finally{
        //                      if(resource != null) resource.close();
        //                  }
        boolean firstTime = true;

        try (Scanner sc = new Scanner(System.in)) {
            
            String input;
            
            while(running){
                
                System.out.print("Expression>>");
                
                input = sc.nextLine();
                
                if(input.equals("end")){
                    
                    running = false;
                    System.out.println("Have a nice day!");
                }
                else{
                    
                    input = addSpace(input);
                    String[] token = input.split(" ");
                    change_negative_sign(token);
                    int state = checkState(token);

                    if((state == 1 || state == 8) && ((firstTime && !input.contains("ans")) || !firstTime)){
                        
                        String[] tokenWithBracket = addBracket(token);
                        
                        String[] postfix = infixToPostfix(tokenWithBracket);
                    
                        System.out.print("Postfix:");
                        
                        for(String s : postfix){
                            
                            System.out.print(s + "");
                        }
                        
                        System.out.println("");
                        
                        previousAns = (double) Math.round(calcPostfix(postfix) * 100) / 100;
                        
                        System.out.println("Ans>>" + previousAns);
                        
                        firstTime = false;
                        
                    }
                    else
                        System.out.println("Syntax error");
                }
            }
        }
    }
    
}
