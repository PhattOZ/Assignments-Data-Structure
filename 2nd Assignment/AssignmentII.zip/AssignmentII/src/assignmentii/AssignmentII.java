
package assignmentii;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class AssignmentII {

    private static final double NANO = 1e9;

    public static void main(String[] args) {
        
        double now, then, deltaTime;                                    //Time related variables
        int comparison;
        
        String fileName = "C:\\Users\\lenovo\\Desktop\\testtest.csv";
        int quantity = 10000;
        
        List<testData> list = readCSVFile(fileName, quantity);          //Read file by calling readCSVFile
        
        List<testData> copy = new ArrayList<>();                                
        
        for(testData t : list){                                         //Using constructor to copy
            
            copy.add(new testData(t));
        }
        
        System.out.println("Sorting random elements");                  //Sorting random elements read from CSV file
        
        now = System.nanoTime();
        comparison = selectionSort(copy);
        then = System.nanoTime();
        deltaTime = (then - now)/NANO;
        System.out.println("Selection sort used: " + deltaTime + " seconds");
        //System.out.println(comparison + " comparisons made");
        
        copy.clear();
        
        for(testData t : list){
            
            copy.add(new testData(t));
        }
        
        now = System.nanoTime();
        comparison = insertionSort(copy);        
        then = System.nanoTime();
        deltaTime = (then - now)/NANO;        
        System.out.println("Insertion sort used: " + deltaTime + " seconds");
        //System.out.println(comparison + " comparisons made");
        
        copy.clear();
        
        for(testData t : list){
            
            copy.add(new testData(t));
        }
        
        now = System.nanoTime();
        comparison = bubbleSort(copy);        
        then = System.nanoTime();
        deltaTime = (then - now)/NANO;        
        System.out.println("Bubble    sort used: " + deltaTime + " seconds");
        //System.out.println(comparison + " comparisons made");
        
        copy.clear();
        
        for(testData t : list){
            
            copy.add(new testData(t));
        }
        
        now = System.nanoTime();
        comparison = shellSort(copy);        
        then = System.nanoTime();
        deltaTime = (then - now)/NANO;        
        System.out.println("Shell     sort used: " + deltaTime + " seconds");
        //System.out.println(comparison + " comparisons made");
        
        copy.clear();
        
        for(testData t : list){
            
            copy.add(new testData(t));
        }
        
        testData extra = new testData(Long.parseLong("738481462718"), "LQSEERFQHEWARIZZIRQOOCEQFCXIXFPEZRYOSXLNNHDZPFCHWCRR", "AMVNPZGLSOUUFKEEGSXEIQTLJXDYEKAIPJBPRUECOULMCYEORRPC");
        list.add(extra);
        
        System.out.println("");
        System.out.println("Adding 1 more element to the sorted array");
        
        now = System.nanoTime();
        comparison = selectionSort(list);       
        then = System.nanoTime();
        deltaTime = (then - now)/NANO;
        System.out.println("Selection sort used: " + deltaTime + " seconds");
        //System.out.println(comparison + " comparisons made");
        
        copy.clear();
        
        for(testData t : list){
            
            copy.add(new testData(t));
        }
        
        now = System.nanoTime();
        comparison = insertionSort(list);        
        then = System.nanoTime();
        deltaTime = (then - now)/NANO;        
        System.out.println("Insertion sort used: " + deltaTime + " seconds");
        //System.out.println(comparison + " comparisons made");
        
        copy.clear();
        
        for(testData t : list){
            
            copy.add(new testData(t));
        }
        
        now = System.nanoTime();
        comparison = bubbleSort(list);        
        then = System.nanoTime();
        deltaTime = (then - now)/NANO;        
        System.out.println("Bubble    sort used: " + deltaTime + " seconds");
        //System.out.println(comparison + " comparisons made");
        
        copy.clear();
        
        for(testData t : list){
            
            copy.add(new testData(t));
        }
        
        now = System.nanoTime();
        comparison = shellSort(list);        
        then = System.nanoTime();
        deltaTime = (then - now)/NANO;        
        System.out.println("Shell     sort used: " + deltaTime + " seconds");
        //System.out.println(comparison + " comparisons made");
        
        copy.clear();
        
        for(testData t : list){
            
            t.setFirstField(t.getFirstField() * -1);
        }
        
        for(testData t : list){
            
            copy.add(new testData(t));
        }
        
        System.out.println("");
        System.out.println("In decending order");
        
        now = System.nanoTime();
        comparison = selectionSort(copy);       
        then = System.nanoTime();
        deltaTime = (then - now)/NANO;
        System.out.println("Selection sort used: " + deltaTime + " seconds");
        //System.out.println(comparison + " comparisons made");
        
        copy.clear();
        
        for(testData t : list){
            
            copy.add(new testData(t));
        }
        
        now = System.nanoTime();
        comparison = insertionSort(copy);        
        then = System.nanoTime();
        deltaTime = (then - now)/NANO;        
        System.out.println("Insertion sort used: " + deltaTime + " seconds");
        //System.out.println(comparison + " comparisons made");
        
        copy.clear();
        
        for(testData t : list){
            
            copy.add(new testData(t));
        }
        
        now = System.nanoTime();
        comparison = bubbleSort(copy);        
        then = System.nanoTime();
        deltaTime = (then - now)/NANO;        
        System.out.println("Bubble    sort used: " + deltaTime + " seconds");
        //System.out.println(comparison + " comparisons made");
        
        copy.clear();
        
        for(testData t : list){
            
            copy.add(new testData(t));
        }
        
        now = System.nanoTime();
        comparison = shellSort(copy);        
        then = System.nanoTime();
        deltaTime = (then - now)/NANO;        
        System.out.println("Shell     sort used: " + deltaTime + " seconds");
        //System.out.println(comparison + " comparisons made");
    }
    
    //Read CSV file using Scanner
    static List<testData> readCSVFile(String fileName, int count){
        
        int i = 0;
        List<testData> data = new ArrayList<>();
        File file = new File(fileName);
        String rawData;
        String[] processed;
        
        try (Scanner inputStream = new Scanner(file)) {
            
            while(inputStream.hasNextLine() && i < count){
                
                rawData = inputStream.nextLine();
                processed = rawData.split(",");
                data.add(new testData(Long.parseLong(processed[1]), processed[2], processed[3]));
                i++;
            }
        }
        catch(FileNotFoundException e){
            
            System.out.println("FILE NOT FOUND");
            return null;
        }
        
        return data;
    }
    
    //Selection sort
    static int selectionSort(List<testData> list){
        
        int comparison = 0;
        testData temp;
        
        for (int i = 0; i < list.size() - 1; i++) {
            
            for (int j = i + 1; j < list.size(); j++) {
                
                if(list.get(i).getFirstField() > list.get(j).getFirstField()){
                    
                    temp = list.get(i);
                    list.set(i, list.get(j));
                    list.set(j, temp);
                }
                
                comparison++;
            }
        }
        
        return comparison;
    }
    
    //Insertion sort
    static int insertionSort(List<testData> list){
        
        int comparison = 0;
        
        for (int i = 1; i < list.size(); i++) {
            
            long key = list.get(i).getFirstField(); 
            int j;
            
            for(j = i; j > 0 && list.get(j - 1).getFirstField() > key; j--){
                
                list.get(j).setFirstField(list.get(j - 1).getFirstField());
                comparison++;
            }
         
            list.get(j).setFirstField(key);
        }
        
        return comparison;
    }
    
    //Bubble sort
    static int bubbleSort(List<testData> list){
        
        int comparison = 0;
        testData temp;
        
        for(int i = 0; i < list.size(); i ++){
            
            for(int j = 0; j < list.size() - 1 - i; j++){
                
                if(list.get(j).getFirstField() > list.get(j + 1).getFirstField()){
                    
                    temp = list.get(j);
                    list.set(j, list.get(j + 1));
                    list.set((j + 1), temp);
                }
                
                comparison++;
            }
        }
        
        return comparison;
    }
    
    //Shell sort
    static int shellSort(List<testData> list){
        
        int h = 1;
        int comparison = 0;
        
        //Knuth's interval sequence
        //is proven to be better than using median
        while(h <= list.size() / 3){
            
            h = 3 * h + 1;
        }
        
        while(h > 0){
            
            for(int i = 0; i < list.size(); i++){
                
                testData temp = list.get(i);
                int j;
                
                for(j = i; j > h - 1 && list.get(j - h).getFirstField() >= temp.getFirstField(); j -= h){
                    
                    list.set(j, list.get(j - h));
                    comparison++;
                }
                
                list.set(j, temp);
            }
            
            h = (h - 1) / 3;
        }
        
        return comparison;
    }
    
    //Print all element in the list
    //Using in debugging process
    static void printList(List<testData> list){
        
        list.forEach((t) -> {
            System.out.println(t.getFirstField() + ", " + t.getSecondField() + ", " + t.getThirdField());
        });
    }
}
