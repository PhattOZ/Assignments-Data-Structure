
package assignmentii;


public class testData {
    
    private long firstField;
    private String secondField;
    private String thirdField;
    
    public testData(long firstField, String secondField, String thirdField){
        
        this.firstField = firstField;
        this.secondField = secondField;
        this.thirdField = thirdField;
    }
    
    public testData(testData t){
        
        this.firstField = t.firstField;
        this.secondField = t.secondField;
        this.thirdField = t.thirdField;
    }
    
    public long getFirstField(){
        
        return this.firstField;
    }
    
    public void setFirstField(long data){
        
        this.firstField = data;
    }
    
    public String getSecondField(){
        
        return this.secondField;
    }
    
    public void setSecondField(String data){
        
        this.secondField = data;
    }
    
    public String getThirdField(){
        
        return this.thirdField;
    }
    
    public void setThirdField(String data){
        
        this.thirdField = data;
    }
}
